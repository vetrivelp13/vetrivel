<?php

/**
 * @file
 * A single location to store configuration.
 */



define('CONSUMER_KEY', 'ee35aa3b9629a69b4130fe5322f88ff804ec62108');
define('CONSUMER_SECRET', 'b07dbcd09d30cfebc0d5b7eb542a4213');
define('ACCESS_TOKEN', '5204d31186f58345a67a2da2a0965b9d04ec62236 ');
define('ACCESS_TOKEN_SECRET', 'cb853b4c25209abcc0352c5b9b0f1f9f');

define('HOSTNAME', 'www.test.com');
define('PROTOCOL', 'http://');
define("OAUTH_SERVER_HOST","http://www.expertusone.com");



define('OAUTH_CALLBACK', PROTOCOL.HOSTNAME.'/apis/expertusone_oauth/net/callback.php');


function getOAuthClient()
{
	$access_oauth_token="";
	$access_token_secret="";
	$userid="";
	$access_oauth_token=ACCESS_TOKEN;//$_COOKIE["oauth_token"];
	$access_token_secret=ACCESS_TOKEN_SECRET;//$_COOKIE["oauth_token_secret"];
	$userid=$_GET["userid"];//$_COOKIE["userid"];


	$_GET["oauth_token"]=$access_oauth_token;
	$_GET["oauth_token_secret"]=$access_token_secret;
	$_GET["userid"]=$userid;
	$connection = new ExpertusONE_OAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_oauth_token,$access_token_secret);
	return $connection;
}

