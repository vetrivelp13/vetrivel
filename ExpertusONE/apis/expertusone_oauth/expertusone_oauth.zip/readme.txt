===== SERVER CONFIGURATION ===== 
Open httpd-vhost file and add the following directory entry in your domain host.

<Directory "E:\wamp\www\sitename">
                Options Indexes FollowSymLinks MultiViews
                AllowOverride All
            
                <IfModule mod_php5.c>
                  php_value magic_quotes_gpc                0
                  php_value register_globals                0
                  php_value session.auto_start              0
                </IfModule>
</Directory>

For example,complete host entry should look like as below

<VirtualHost *:80>
    DocumentRoot E:\wamp\www\sitename
    UseCanonicalName Off
    ServerSignature On
    ServerName www.sitename.com
            RewriteEngine on
            RewriteRule ^/services/(.*)$ /sites/all/services/LnrService.php?soapaction=$1 [L]
            RewriteRule ^/services/(.*)?WSDL$ /sites/all/services/LnrService.php?soapaction=$1&showWSDL=true [L]

        <Directory "E:\wamp\www\sitename">
                Options Indexes FollowSymLinks MultiViews
                AllowOverride All
               # Order allow,deny
               # Allow from all

                <IfModule mod_php5.c>
                  php_value magic_quotes_gpc                0
                  php_value register_globals                0
                  php_value session.auto_start              0
                </IfModule>
        </Directory>
   
</VirtualHost>




===== Open the downloaded client library and find config.php
1. Update the following keys in config.php
CONSUMER_KEY
CONSUMER_SECRET
ACCESS_TOKEN
ACCESS_TOKEN_SECRET
2. Update HOSTNAME and PROTOCOL in config.php
3. Update OAUTH_SERVER_HOST in config.php (LMS server domain)
4. Update OAUTH_CALLBACK url in config.php.  If expertusone_oauth folder placed under root folder then entry will be
            define('OAUTH_CALLBACK', HOSTNAME.'/expertusone_oauth/net/callback.php');
5. If you do not have access_token, launch the following url
           http://yourdomain/expertusone_oauth/net/authenticate.php
6.Provide admin user name and password in product login page and click Login
7. Grant access, it will provide the access_token and access_token_secret keys, Copy the values and update it in config.php
8. Goto API documentation, and call the API.
